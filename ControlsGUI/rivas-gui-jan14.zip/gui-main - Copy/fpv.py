import sys
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import cv2

class MainWindow(QWidget):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.VBL = QVBoxLayout()

        self.FeedLabel = QLabel()
        self.VBL.addWidget(self.FeedLabel)

        self.CancelBTN = QPushButton("Cancel Feed")
        self.CancelBTN.clicked.connect(self.CancelFeed)
        self.VBL.addWidget(self.CancelBTN)

        # create an instance of the QThread class
        self.Worker1 = Worker1()
        # starts the QThread class
        self.Worker1.start()
        #
        self.Worker1.ImageUpdate.connect(self.ImageUpdateSlot)
        self.setLayout(self.VBL)

    # connect the video signal to a recieving slot in the main window
    def ImageUpdateSlot(self, Image):
        # changes the label to the current video frame
        self.FeedLabel.setPixmap(QPixmap.fromImage(Image))
        #self.FeedLabel.setPixmap(QPixmap.fromImage(QImage(self.Image.data, self.Image.shape[1], self.Image.shape[0], QImage.Format_RGB32)))

    def CancelFeed(self):
        self.Worker1.stop()

class Worker1(QThread):
    ImageUpdate = pyqtSignal(QImage)
    def run(self):
        self.ThreadActive = True
        Capture = cv2.VideoCapture(0) # select camera source. built in laptop camera = 1, usb camera = 2
        while self.ThreadActive:
            ret, frame = Capture.read()
            if ret:
                Image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                #Image = cv2.rotate(frame, cv2.ROTATE_90) # rotate image 90 deg
                #Image = cv2.flip(Image, 0) # flip the image
                ConvertToQtFormat = QImage(Image.data, Image.shape[1], Image.shape[0], QImage.Format_RGB888)
                Pic = ConvertToQtFormat.scaled(640, 480, Qt.KeepAspectRatio)
                self.ImageUpdate.emit(Pic)
    def stop(self):
        self.ThreadActive = False
        self.quit()

if __name__ == "__main__":
    App = QApplication(sys.argv)
    App.setApplicationName("FPV Live Feed")
    Root = MainWindow()
    Root.show()
    sys.exit(App.exec())
