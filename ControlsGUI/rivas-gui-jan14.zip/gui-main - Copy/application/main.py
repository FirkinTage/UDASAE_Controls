# UD ASAE Ground Station GUI v2

# Import Modules
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import cv2
import serial.tools.list_ports 
import serial as sr 
import csv

# Import UI files
from ui_main import Ui_MainWindow
from ui_splashscreen import Ui_SplashScreen

# Global Variables
counter = 0



class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow,self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # remove title bar
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # add page btn click functionality
        self.ui.btn_page_1.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.page_1))
        self.ui.btn_page_2.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.page_2))
        self.ui.btn_page_3.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.page_3))
        self.ui.btn_close.clicked.connect(lambda: self.close())
        self.ui.btn_minimize.clicked.connect(lambda: self.showMinimized())
        self.ui.btn_maximize.clicked.connect(lambda: self.showMaximized())
        
        # set up the video feed
        self.ui.CancelBTN.clicked.connect(self.CancelFeed)
        self.ui.Worker1 = Worker1()
        self.ui.Worker1.start()
        self.ui.Worker1.ImageUpdate.connect(self.ImageUpdateSlot)

        # set up the DAS 
        self.ui.Worker2 = Worker2()
        self.ui.Worker2.start()
        self.ui.Worker2.TextUpdate.connect(self.TextUpdateSlot)
        self.ui.Worker2.TableUpdate.connect(self.TableUpdateSlot)

        self.ui.CancelBTN2.clicked.connect(self.CancelData)
        
        
    def TextUpdateSlot(self, serialDict):
        #print('recieved serial packet')
        self.ui.label_current_alt.setText(str(serialDict['alt']))
        self.ui.label_cdadrop_alt.setText(str(serialDict['cdaHeight']))
        self.ui.label_supplydrop_alt.setText(str(serialDict['habHeight']))
        self.ui.label_pitch.setText(str(serialDict['gyroy'])) 
        self.ui.label_roll.setText(str(serialDict['gyrox'])) 
        self.ui.label_yaw.setText(str(serialDict['gyroz'])) 
        self.ui.label_speed.setText(str(serialDict['spd']))
        self.ui.rssi.setValue(abs(serialDict['rssi']))
        
    
    @pyqtSlot(QImage) # (optional) decorator to indicate what object the signal will provide.
    def ImageUpdateSlot(self, Image):
        #print('recieved video frames')        
        self.ui.FeedLabel.setPixmap(QPixmap.fromImage(Image))


    def CancelFeed(self):
        self.ui.Worker1.stop()

    def CancelData(self):
        self.ui.Worker2.stop()

    def TableUpdateSlot(self, serialDict):
        
        if serialDict['cdaHeight'] != 0:
            self.ui.frame_circle_cda_alt.setStyleSheet("QFrame{\n"
    "    border: 5px solid rgb(0, 255, 0);\n"
    "    border-radius: 105px;\n"
    "}\n"
    "QFrame:hover {\n"
    "    border: 5px solid rgb(0, 255, 0, 150);\n"
    "}")    
            pass
        if serialDict['habHeight'] != 0:
            self.ui.frame_circle_supply_alt.setStyleSheet("QFrame{\n"
    "    border: 5px solid rgb(0, 255, 0);\n"
    "    border-radius: 105px;\n"
    "}\n"
    "QFrame:hover {\n"
    "    border: 5px solid rgb(0, 255, 0, 150);\n"
    "}")
            pass
        

        with open('das_data.csv','a', newline='') as f:
            w = csv.writer(f)
            #print(serialDict.keys())
            w.writerow(serialDict.values())
            #w.writerows(serialDict.values())
            
        
        # add new row and populate with DAS data
        #rowPosition = self.ui.das_table.rowCount()
        #self.ui.das_table.insertRow(rowPosition)

        
        #self.ui.das_table.setItem(rowPosition, 0, QtWidgets.QTableWidgetItem(str(serialDict['pkt'])))
        """
        self.ui.das_table.setItem(rowPosition, 1, QtWidgets.QTableWidgetItem(str(serialDict['alt'])))
        self.ui.das_table.setItem(rowPosition, 2, QtWidgets.QTableWidgetItem(str(serialDict['lat'])))
        self.ui.das_table.setItem(rowPosition, 3, QtWidgets.QTableWidgetItem(str(serialDict['lon'])))
        self.ui.das_table.setItem(rowPosition, 4, QtWidgets.QTableWidgetItem(str(serialDict['hdng'])))
        self.ui.das_table.setItem(rowPosition, 5, QtWidgets.QTableWidgetItem(str(serialDict['spd'])))
        self.ui.das_table.setItem(rowPosition, 6, QtWidgets.QTableWidgetItem(str(serialDict['habHeight'])))
        self.ui.das_table.setItem(rowPosition, 7, QtWidgets.QTableWidgetItem(str(serialDict['cdaHeight'])))
        self.ui.das_table.setItem(rowPosition, 8, QtWidgets.QTableWidgetItem(str(serialDict['watHeight'])))
        self.ui.das_table.setItem(rowPosition, 9, QtWidgets.QTableWidgetItem(str(serialDict['rssi'])))
        print('populated serial packet')
        """



class SplashScreen(QMainWindow):
    def __init__(self):
        super(SplashScreen,self).__init__()
        self.ui = Ui_SplashScreen()
        self.ui.setupUi(self)

        # remove title bar
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # drop shadow effect
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(20)
        self.shadow.setXOffset(0)
        self.shadow.setYOffset(0)
        self.shadow.setColor(QColor(0, 0, 0, 60))
        self.ui.dropShadowFrame.setGraphicsEffect(self.shadow)

        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.progress)
        self.timer.start(15)

        self.ui.label_description.setText("<strong>UD ASAE</strong> Ground Station GUI")
        QtCore.QTimer.singleShot(1500, lambda: self.ui.label_description.setText("<strong>LOADING</strong> dependancies"))
        
        self.show() # show main window

    def progress(self):
        global counter
        self.ui.progressBar.setValue(counter)

        # close splash screen and open main gui
        if counter > 100:
            self.timer.stop()
            self.main = MainWindow()
            self.main.show()
            self.close()

        counter += 1


# FPV thread
class Worker1(QThread):
    ImageUpdate = pyqtSignal(QImage)
    
    def run(self):
        self.ThreadActive = True    
        Capture = cv2.VideoCapture(0) 

        while self.ThreadActive:
            ret, frame = Capture.read()
            
            if self.ThreadActive & ret:
                Image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                ConvertToQtFormat = QImage(Image.data, Image.shape[1], Image.shape[0], QImage.Format_RGB888)
                Pic = ConvertToQtFormat.scaled(640, 480, Qt.KeepAspectRatio)
                self.ImageUpdate.emit(Pic)
                #print('sent good frames')
            
    def stop(self):
        #print('!!!!STOP VIDEO FEED!!!!!\n')
        self.ThreadActive = False


# DAS thread
class Worker2(QThread):
    TextUpdate = pyqtSignal(dict)
    TableUpdate = pyqtSignal(dict)

    # set up .csv to store serial packets, note this will re-write every time gui is launched
    cols = ['pkt', 'drp', 'alt', 'lat', 'lon', 'hdng', 'spd', 'aclx', 'acly', 'aclz', 'magx', 'magy', 'magz', 'gyrox', 'gyroy', 'gyroz', 'habHeight', 'cdaHeight', 'watHeight', 'rssi']
    with open('das_data.csv','w') as f:
        w = csv.writer(f)
        w.writerow(cols)
        
    def run(self):
        self.ThreadActive = True     

        comList = serial.tools.list_ports.comports()
        connected = []
        for element in comList:
            connected.append(element.device)
        #print(connected)
            
        s = sr.Serial('COM3', 9600)  # update comPort str to whichever yours is on 
        s.reset_input_buffer()

        while self.ThreadActive:
            #Read data in serial buffer
            serialString=s.readline().rstrip().decode("utf-8")     
            try:
                #Try to convert the raw string into a dictionary
                serialDict=eval(serialString)
            #catch any errors when trying to convert to dictionary
            except (NameError,SyntaxError,ValueError) as e:
                #print('worker:',e)
                pass
            else:
                #print('sent serial packet')
                self.TextUpdate.emit(serialDict)
                self.TableUpdate.emit(serialDict)


    def stop(self):
        #print('!!!!STOP DATA COLLECTION!!!!!\n')
        self.ThreadActive = False   


def window():
    app = QApplication(sys.argv)
    win = SplashScreen()
    sys.exit(app.exec_())

window()

